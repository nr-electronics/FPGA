#ifndef __PLATFORM_CONFIG_H__
#define __PLATFORM_CONFIG_H__

#include "stm32f10x.h"

#endif // __PLATFORM_CONFIG_H__
